﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalasApp
{
    public class ReservasAceptadas
    {
        public List<Reservas> ResAceptadas = new List<Reservas>();

        
    }
}
