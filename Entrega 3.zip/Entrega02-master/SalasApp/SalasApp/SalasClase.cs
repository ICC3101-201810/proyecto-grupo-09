﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalasApp
{
    class SalasClase: Salas
    {
        public SalasClase(List<string> equipamiento, List<string> horario, string codigo)
            : base(equipamiento, horario, codigo)
        {

        }
    }
}
